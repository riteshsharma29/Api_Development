from fastapi import FastAPI
from fastapi import Path
from pydantic import BaseModel
from typing import Optional
import pandas as pd
import sqlite3
import json,ast


'''
https://www.youtube.com/watch?v=-ykeT6kk4bk&t=932s
https://www.youtube.com/watch?v=tLKKmouUams&t=942s
https://www.freecodecamp.org/news/fastapi-helps-you-develop-apis-quickly/
https://towardsdatascience.com/how-to-convert-json-into-a-pandas-dataframe-100b2ae1e0d8
http://127.0.0.1:8000/docs
https://github.com/vnurhaqiqi/fastapi-sqlite
uvicorn first:app --reload
'''


# instantiating fastapi class
app = FastAPI()

# connecting sqlite3 employee.db database
con = sqlite3.connect('employee.db')
# creating connection object
cur = con.cursor()

# post_dict = {
#   "Name": "jon",
#   "Lastname": "van",
#   "Email": "jon@gmail.com",
#   "Designation": "Engg",
#   "Salary_in_USD": 20000
# }
# query = "insert into datatable " + str(tuple(post_dict.keys())) + " values" + str(tuple(post_dict.values())) + ";"
# cur.execute(query)
# con.commit()

class Employee(BaseModel):
    Name: str
    Lastname: str
    Email: str
    Designation: str
    Salary_in_USD: int

# function to query employee.db / GET Method
def dbquery(query):
    result = pd.read_sql(query,con).to_dict()
    return result


# function to query employee.db
def dbquery_post(post_dict):
    # query = "insert into datatable " + str(tuple(post_dict.keys())) + " values" + str(tuple(post_dict.values())) + ";"
    # cur.execute(query)
    # con.commit()
    # con.refresh()
    print(post_dict)



# storing all employees table data in a dictionary
employees = dbquery("select * from `datatable`;")
employees_json = {}
for i in range(0,len(employees["Name"])):
    employees_json[i] = {
        "Name": employees["Name"][i],
        "Lastname": employees["Lastname"][i],
        "Email": employees["Email"][i],
        "Designation": employees["Designation"][i],
        "Salary_in_USD": employees["Salary_in_USD"][i]
    }

# Path parameter (we need to add parameter to endpoint)
@app.get("/get-employee/{employee_id}")
def get_employee(employee_id: int=Path(None,description="The ID of the employee you want to view",gt=0)):
    return employees_json[employee_id]

# Query parameters (we don't need to add parameter to endpoint)
@app.get("/get-by-name")
def get_employee(*, name:Optional[str] = None):
    for employee_id in employees_json:
       if employees_json[employee_id]["Name"] == name:
           return employees_json[employee_id]
    return {"Data":"Not Found"}

# combining path and query parameters
@app.get("/get-by-name-and-id/{employee_id}")
def get_employee(*, employee_id : int, name:Optional[str] = None, test : int):
    for employee_id in employees_json:
       if employees_json[employee_id]["Name"] == name:
           return employees_json[employee_id]
    return {"Data":"Not Found"}

# Request Body and The Post method
@app.post("/create-employee/{employee_id}")
def create_employee(employee_id : int,employee:Employee):
    if employee_id in employees_json:
        return {"Error":"Employee exists"}
    employees_json[employee_id] = employee
    return employees_json[employee_id]
    print(dbquery_post(employees_json[employee_id]))




