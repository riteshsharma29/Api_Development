from sqlalchemy.orm import Session

import models, schemas
# from .helper import *
from models import User

def get_user(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.ID == user_id).first()

def get_user_by_name(db: Session, user_name: str):
    return db.query(models.User).filter(models.User.Name == user_name).first()

def get_user_by_id_or_name(db: Session, user_id: int, user_name: str):
    return db.query(models.User).filter(models.User.ID == user_id and models.User.Name == user_name).first()

def list_users(db:Session):
    """
    Return a list of all existing Friend records
    """
    all_employees = db.query(User).all()
    return all_employees

def create_user(db: Session,Name,Lastname,Email,Designation,Salary_in_USD):
    new_user = User(Name=Name, Lastname=Lastname, Email=Email,Designation=Designation,Salary_in_USD=Salary_in_USD)
    #place object in the database session
    db.add(new_user)
    #commit your instance to the database
    db.commit()
    #reefresh the attributes of the given instance
    db.refresh(new_user)
    return new_user

def update_user(db:Session, user_id:int,Name:str,Lastname:str, Email: str, Designation: str, Salary_in_USD:int):
    """
    Update a Friend object's attributes
    """
    db_user = get_user(db=db, user_id=user_id)
    db_user.Name = Name
    db_user.Lastname = Lastname
    db_user.Email = Email
    db_user.Designation = Designation
    db_user.Salary_in_USD = Salary_in_USD
    db.commit()
    db.refresh(db_user) #refresh the attribute of the given instance
    return db_user


def delete_user(db:Session, user_id:int):
    """
    Delete a Friend object
    """
    db_user = get_user(db=db, user_id=user_id)
    db.delete(db_user)
    db.commit()



















# def get_user_by_email(db: Session, email: str):
#     return db.query(models.User).filter(models.User.email == email).first()
#
#
# def get_users(db: Session, skip: int = 0, limit: int = 100):
#     return db.query(models.User).offset(skip).limit(limit).all()
#
#
# def create_user(db: Session, user: schemas.UserCreate):
#     hashed_password = get_hashed_password(plain_text_password=user.password)
#     db_user = models.User(email=user.email, hashed_password=hashed_password)
#     db.add(db_user)
#     db.commit()
#     db.refresh(db_user)
#
#     return db_user
#
#
# def get_home_works(db: Session, skip: int = 0, limit: int = 100):
#     return db.query(models.HomeWork).offset(skip).limit(limit).all()
#
#
# def create_user_home_work(db: Session, home_work: schemas.HomeWorkCreate, user_id: int):
#     db_home_work = models.HomeWork(**home_work.dict(), owner_id=user_id)
#     db.add(db_home_work)
#     db.commit()
#     db.refresh(db_home_work)
#
#     return db_home_work
