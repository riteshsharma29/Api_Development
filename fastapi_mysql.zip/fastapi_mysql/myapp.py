from typing import List

from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
import crud
import models
import schemas
from database import SessionLocal, engine
from schemas import User

'''
sqlite3 example :
https://dev.to/mungaigikure/simple-fastapi-crud-3ad0
'''

models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Employee Details",
    description="You can perform CRUD operation by using this API",
    version="1.0.0"
)


# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# @app.post('/users/', response_model=schemas.User)
# def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
#     db_user = crud.get_user_by_email(db, email=user.email)
#
#     if db_user:
#         raise HTTPException(status_code=400, detail="Email already registered.")
#
#     return crud.create_user(db=db, user=user)


# @app.get('/users/', response_model=List[schemas.User])
# def read_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
#     users = crud.get_users(db, skip=skip, limit=limit)

    # return users


@app.get("/get_by_user_id/{user_id}", response_model=schemas.User)
def read_user(user_id: int, db: Session = Depends(get_db)):
    db_user = crud.get_user(db, user_id=user_id)
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found.")
    return db_user

@app.get("/get-by-name",response_model=schemas.User)
def read_name(*, user_name:Optional[str] = None,db: Session = Depends(get_db)):
    db_name = crud.get_user_by_name(db, user_name=user_name)
    if not db_name:
        raise HTTPException(status_code=404, detail="User not found.")
    return db_name

@app.get("/get-by-name-or-id/{employee_id}",response_model=schemas.User)
def read_name_or_id(*, user_id: int, user_name: Optional[str] = None,db: Session = Depends(get_db)):
    db_name = crud.get_user_by_id_or_name(db, user_id=user_id,user_name=user_name,)
    if not db_name:
        raise HTTPException(status_code=404, detail="User not found.")
    return db_name

@app.get("/list_employees")
def list_users(db:Session = Depends(get_db)):
    """
    Fetch a list of all employees object
    Returns a list of objects
    """
    users_list = crud.list_users(db=db)
    return users_list

@app.post("/create_employee")
def create_friend(Name:str, Lastname:str, Email:str, Designation:str, Salary_in_USD:int, db:Session = Depends(get_db)):
    New_Employee = crud.create_user(db=db, Name=Name, Lastname=Lastname, Email=Email,Designation=Designation,Salary_in_USD=Salary_in_USD)
##return object created
    return {"New Employee": New_Employee}


@app.put("/update_user/{employee_id}/") #id is a path parameter
def update_user(user_id:int, Name:str, Lastname:str, Email:str, Designation:str, Salary_in_USD:int, db:Session=Depends(get_db)):
    #get employee object from database
    db_user = crud.get_user(db=db, user_id=user_id)
    #check if friend object exists
    if db_user:
        updated_user = crud.update_user(db=db, user_id=user_id, Name=Name, Lastname=Lastname, Email=Email,Designation=Designation,Salary_in_USD=Salary_in_USD)
        return updated_user
    else:
        return {"error": f"Employee with id {user_id} does not exist"}


@app.delete("/delete_user/{employee_id}/") #id is a path parameter
def delete_friend(user_id:int, db:Session=Depends(get_db)):
    #get friend object from database
    db_user = crud.get_user(db=db, user_id=user_id)
    #check if friend object exists
    if db_user:
        return crud.delete_user(db=db, user_id=user_id)
    else:
        return {"error": f"Employee with id {user_id} does not exist"}


# @app.post('/users/{user_id}/home-works/', response_model=schemas.HomeWork)
# def create_home_work_for_user(user_id: int, home_work: schemas.HomeWorkCreate, db: Session = Depends(get_db)):
#     return crud.create_user_home_work(db=db, home_work=home_work, user_id=user_id)
#
#
# @app.get('/home-works/', response_model=List[schemas.HomeWork])
# def read_home_works(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
#     home_works = crud.get_home_works(db, skip=skip, limit=limit)
#
#     return home_works
