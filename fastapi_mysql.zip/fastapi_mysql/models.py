from sqlalchemy import Boolean, Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from database import Base


class User(Base):
    __tablename__ = 'datatable'

    ID = Column(Integer, primary_key=True, index=True)
    Name = Column(String(40),)
    Lastname = Column(String(40))
    Email = Column(String(40))
    Designation = Column(String(40))
    Salary_in_USD = Column(Integer)
